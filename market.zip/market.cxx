#include<stdio.h>
#include<windows.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
typedef struct {
    char libel[20];
    unsigned int code;
    double price;
    unsigned int stair;
}shop;
void search_product_by_price()
{
    FILE*fp;
    shop info;
    int  found = 0;
    double spending = 0;
    int j =0;
    int i = 1;
    double search_price;
    fp=fopen("Shop.txt","r");
    system("CLS");
     printf(" \n\n\t======RECHERRCHER DES PRODUITS======");
    if(fp==NULL){
        fprintf(stderr,"\n\tImpossible d'ouvrir le fichier");
    }
    else{ printf("\n\tEntrer le prix du produit a chercher>>");
    fflush(stdin); scanf("%lf",&search_price);
    while (fread(&info,sizeof(shop),1,fp))
       {  
         if(search_price==info.price){
		    found=1;
		    printf("\n\n\t======= Produits Touves ======\n\n");
		    printf("\t__________________________________\n");          
            printf("\tNumero du produit    :: %d\n",i);
            printf("\tLibelle  du produit  :: %s\n",info.libel);
            printf("\tCode   du produit    ::%d\n",info.code);
            printf("\tPrix  du produit     ::%.2lf\n",info.price);
            printf("\tNumero de l\'etagere  ::%d\n",info.stair);
            i++;
            j = j+i;
            spending = spending + info.price;
       }
       }
      if(found == 0){
      	printf("\n\t====================================\n");
            printf("\n\tProduit non touve");
       	printf("\n\t====================================\n");
          
          }
    }
                printf("\n\t ====informations detaillees====");
                printf("\n\\t Nombre de produits trouves ::%d", j);
                printf("\n\tDepense des produits trouves::%.2lf",spending);
				printf("\n\t\__________________________________\n"); 
                  fclose(fp);
}

 void general_search()
 {  void search_product_by_libelle();
    void search_product_by_price();
    int rep;
	 printf("\n\tTAPER 1 POUR RECHERCHE PAR LIBELLE ET 2 PAR PRIX:");
     scanf("%d",&rep);
 	if(rep==1){
 		search_product_by_libelle();
	 }
	else{
		if(rep==2){
			search_product_by_price();
			
		}
		else{
			printf("\n\t=======================CHOIX NOn VALIDE======================");
		}
	}
 }


void search_product_by_libelle()
{
    FILE*fp;
    shop info;
    int  found = 0;
    double spending = 0;
    int j =0;
    int i = 1;
    char search_libelle[40];
    fp=fopen("Shop.txt","r");
    system("CLS");
     printf(" \n\n\t======RECHERRCHER DES PRODUITS======");
    if(fp==NULL){
        fprintf(stderr,"\n\tImpossible d'ouvrir le fichier");
    }
    else{ printf("\n\tEntrer le libelle du produit a chercher>>");
    fflush(stdin); scanf("%s",&search_libelle);
    while (fread(&info,sizeof(shop),1,fp))
       {  
         if(strcmp(search_libelle,info.libel)==0){
		    found=1;
		    printf("\n\n\t======= Produits Touves ======\n\n");
		    printf("\t\t\t\t__________________________________\n");          
            printf("Numero du produit    :: %d\n",i);
            printf("Libelle  du produit  :: %s\n",info.libel);
            printf("\tCode   du produit    ::%d\n",info.code);
            printf("\tPrix  du produit     ::%.2lf\n",info.price);
            printf("\tNumero de l\'etagere  ::%d\n",info.stair);
            i++;
            j = j+i;
            spending = spending + info.price;
       }
       }
      if(found == 0){
      	printf("\n\t\t\t\t====================================\n");
            printf("\n\t        Produit non touve");
       	printf("\n\t\t\t\t====================================\n");
          
          }
    }
                printf("\n\t ====informations detaillees====");
                printf("\n\t Nombre de produits trouves ::%d", j);
                printf("\n\tDepense des produits trouves::%.2lf",spending);
				printf("\n\t__________________________________\n"); 
                  fclose(fp);
}





void adding_of_products()
{  FILE *fp;
   fp=fopen("Shop.txt","a");
   char ans;
   shop info;
   ;   
    do{
    	clrscr();
    printf(" \n\n\t======AJOUTER LES INFORMATIONS DES PRODUITS======");
    printf(" \n\n\tEntrer le libelle du prouit :");
    fflush(stdin);scanf("%s",&info.libel);
    printf("\n\n\t Entrer le code du produit :");
    fflush(stdin);scanf("%d",&info.code);
    printf("\n\n \tEntrer le prix du produit :");
    fflush(stdin);scanf("%lf",&info.price);
    printf(" \n\n\tEntrer le numero de l\'etagere :");
    fflush(stdin);scanf("%d",&info.stair); 
    if(fp==NULL){
        fprintf(stderr, "\n\tImpossible d'ouvrir le fichier");
    }
    else{
    	fwrite(&info, sizeof(shop),1,fp);
    printf("\n\n\t___________________________________________\n");
    printf("\t======Produit enregistere avec succes======\n}");
    	
	}
    printf("\n\tAJOUTER UN PROUDIT? (O) ou(N)>>");
   fflush(stdin); scanf("%c",&ans);
    } while(ans =='O'||ans=='o');
    
 fclose(fp);
}

void display_items()
{
    FILE*fp;
    shop info;
    double spending = 0;
    int j =0;
    int i = 1;
    fp=fopen("Shop.txt","r");
    printf(" \n\n\t======AFFICHES LA LISTE DES PRODUITS======");
    if(fp==NULL){
        fprintf(stderr, "\n\tImpossible d'ouvrir le fichier");
    }
    printf("\n\n\t======= Produits enregistres ======\n\n");
    while (fread(&info,sizeof(shop),1,fp))
       { 
           printf("\t\t__________________________________\n");          
           printf("\tNumero du produit    :: %d\n",i);
           printf("\tLibelle  du produit  :: %s\n",info.libel);
           printf("\tCode   du produit    ::%d\n",info.code);
           printf(" \tPrix  du produit     ::%.2lf\n",info.price);
           printf("\tNumero de l\'etagere  ::%d\n",info.stair);
           i++;
           j = j+i;
           spending = spending + info.price;
       }    
                printf("\n\t====informations detaillees====");
                printf("\n\tNombre de produits saisi ::%d", j);
                printf("\n\tDepense global::%.2lf",spending);
			    printf("\n\t__________________________________\n"); 
	 fclose(fp);
 }


void delete_items()
{
	FILE*fp, *fp1;
    shop info;
    int found_del = 0;
    int num;
    fp=fopen("Shop.txt","r");
     fp1=fopen("temp.txt","w");
     printf("\n\tEtrer le code du produit a supprimer");
     scanf("%d",num);
    printf(" \n\n\t======SUPRESSIN DES ARTICLES======");
    if(fp==NULL){
        fprintf(stderr, "\n\tImpossible d'ouvrir le fichier");
    }
     while (fread(&info,sizeof(shop),1,fp))
       { 
       if(num==info.code){
       	 found_del = 1;
	   }
	   else{
	   	fwrite(&info,sizeof(shop),1,fp1);
	   }
       
   }
   fclose(fp);
   fclose(fp1);
   
   if(found_del){
   	remove("Shop");
   	rename("temp.tx","Shop.tx");
   	printf("\ntL'enregistrement a ete supprime avec success");
   }
   if(!found_del){
   	printf("\n\tL'enregistrement non trouve");
   }
}













int main(int argc, char *argv[])
{  int choice;
    clrscr();
	while(choice!=6){
	printf("\n\t ________________________________\n");  
	printf("\t    1: Ajouter un produit:\n");
	printf("\t    2: Modifier un produit\n");
	printf("\t    3: Chercher un produit\n");
	printf("\t    4: Supprimer un produit\n");
	printf("\t    5: Afficher les produits\n");
	printf("\t    6: Quitter");
	printf("\n\t ________________________________\n");
    printf("\n\n\t       Faite une option:");
	 scanf("%d",&choice);
	 getch();
	 switch(choice){
	     case 1: clrscr();
	      adding_of_products();
	      clrscr();
	      printf("Appuyer sur une touche pour sortir");
	     getch();
	     clrscr();
	     break;
	     case 3:
	     	clrscr();
	      printf("\n\t\t\t\tAppuyer sur une touche pour sortir");
	     getch();  
	     clrscr();
	     break;
	     case 4:
	     	clrscr();
	      delete_items();
	      printf("\n\t\t\t\tAppuyer sur une touche pour sortir");
	     getch();  
	     clrscr();
	     case 5:
	     	clrscr();
	     display_items();
	     printf("\n\t\t\t\tAppuyer sur une touche pour sortir");
	     getch();
	     clrscr();
	     break;
	 }
}
}
