from cv2 import QRCodeDetector
import pyqrcode
from pyqrcode import QRCode
link="https://www.hamadosimean.github.io/simean/"
qr_code=pyqrcode.create(link)
qr_code.svg('Hamadosimean.svg',scale=5)
