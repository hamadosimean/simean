from tkinter import * #module pour l'interface graphique'
#copyright Simean Hamado 11/10/22
from tkinter import messagebox
from  countryinfo import CountryInfo #module pour les info des pays
#import pyttsx3
#engine= pyttsx3.init() #dire a la machine de parle, text en vocal
t=Tk()
t.geometry("200x150")
t['bg']='darkorange'

def infoc(): #fonction qui retourne les infos
    pay=ent.get()
    payinfo=ent2.get()
    if pay=="":
        messagebox.showerror("Vous n'avez pas saisi de pays.")
    if payinfo=="":
        messagebox.showerror("Champ vide. veuiller saisir quelque chose.")
    if(payinfo.lower()=="capital"):
         pays=CountryInfo(str(pay))
         inf=pays.capital()
      #   engine.say(inf)
       #  engine.runAndWait()
         Message(t,text=str(inf),fg='white',bg='blue',font='Arial 6 bold',width=200).pack(pady=5)
    elif (payinfo.lower()=="monnaie"):
         pays=CountryInfo(str(pay))
         inf=pays.currencies()
     #    engine.say(inf)
      #   engine.runAndWait()
         Message(t,text=str(inf) ,fg='white',bg='blue',font='Arial 6 bold').pack(pady=5)
    elif (payinfo.lower()=="autre nom"):
         pays=CountryInfo(str(pay))
         inf=pays.alt_spellings() 
   #   engine.say(inf)
     # engine.runAndWait()
         Message(t,text=str(inf) ,fg='white',bg='blue',font='Arial 6 bold').pack(pady=5)
    elif (payinfo.lower()=="pays frontieres"):
         pays=CountryInfo(str(pay))
         inf=pays.borders() 
         for i in inf:
              Message(t,text=str(i) ,fg='white',bg='blue',font='Arial 6 bold').pack(pady=5)
          #  engine.say(inf)
            #engine.runAndWait()
    elif (payinfo.lower()=="langues parlees"):
         pays=CountryInfo(str(pay))
         inf=pays.languages() 
         for i in inf:
               Message(t,text=str(i),fg='white',bg='blue',font='Arial 6 bold').pack(pady=5) 
    elif (payinfo.lower()=="provinces"):
         pays=CountryInfo(str(pay))
         inf=pays.provinces() 
         Message(t,text=str(inf),fg='white',bg='blue',font='Arial 6 bold').pack(pady=5)
    else:     
         pays=CountryInfo(str(pay))
         inf=pays.info() 
         Message(t,text=str(inf),fg='white',bg='blue',font='Arial 4 bold').pack(pady=5)
msg='Information de tous les pays'        
Label(t,text=msg.upper(),bg='blue',font='Arial 12 bold',fg='white').pack(pady=10)

ent=StringVar()
ent2=StringVar() #les variables

Label(t,text='Entrer le pays',width=30).pack()
Entry(t,textvariable=ent,width=30).pack(pady=5)

Label(t,text='Entrer info, ex:capital',width=30).pack()
Entry(t,textvariable=ent2,width=30).pack(pady=5)


Button(t,text="Voir pays info",fg='blue',font='Georgia 10 bold',command=infoc).pack(pady=20)
t.mainloop()