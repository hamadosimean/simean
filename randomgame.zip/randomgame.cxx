#include<iostream>
#include<conio.h>
#include<cstdlib>
#include<ctime>
using namespace std;

int main(int argc, char *argv[])
{
	int high=15;
	int low=5;
	int guess;
	srand(time(0));
	int num= rand()%(high-low+1)+low;
	int trylimit=5;
	bool found=false;
	int counter=1;
	int i=4;
	
	while(counter<=trylimit && !found)
	{ 
	 do{
	    cout<<"Choisir un nombre compris entre 5 et 15 ";
	    cin>>guess;
	    clrscr();
	}while(guess<5 || guess>15);
	
	if(guess==num){
	    found=true;
	    cout<<"Felicitation!Vous avez trouvé le nombre"<<endl;
   cout<<"Le nombre etait: "<<num<<endl;
	}
	else if(guess>num){  cout<<"le nombre choisi est grand. Choisissez un nombre plus petit"<<endl;	  
   cout<<"Il vous reste "<<i<< " essai"<<endl;
	}
	else{   cout<<"le nombre choisi est  petit. Choisissez un nombre plus grand"<<endl;
	    cout<<"Il vous reste: "<<i<<" essai"<<endl;
	}
		if(i==0){
	    cout<<"Le nombre d'essai est atteint"<<endl;
	    return 1;
	}
	counter++;
	i--;

	}
}