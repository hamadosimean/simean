import cv2
import matplotlib.pyplot as plt
cascade=cv2.CascadeClassifier('haarcascade_frontalface_alt.xml')
im=cv2.imread("img2.jpg")
face=cascade.detectMultiScale(im,1.1,4)
for ( x , y ,w,h) in face:
    cv2.rectangle(im,(x,y),(x+w,y+h),(255,0,0),5)
plt.imshow(im)
plt.show()