/***************************************************************
* The interface file for the function template named smaller *
***************************************************************/
#ifndef SMALLER_H
#define SMALLER_H
#include <iostream>
using namespace std;
template <typename T>
T smaller (const T& first, const T& second)
{
if (first < second)
{
return first;
}
return second;
}
#endif
/***************************************************************
* The application file to test a function template *
***************************************************************/
#include "smaller.h"
int main ( )
{
cout << "Smaller of 'a' and 'B': " << smaller ('a', 'B') << endl;
cout << "Smaller of 12 and 15: " << smaller (12, 15) << endl;
cout << "Smaller of 44.2 and 33.1: " << smaller (44.2, 33.1) << endl;
return 0;
}
