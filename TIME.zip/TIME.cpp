#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>

int main()
{
	int hours,minutes,seconds;
	hours = minutes = seconds = 0;
	 printf("Entrer l'heure actuelle sous le format: HH: MM : SS:");
	 scanf("%d %d %d", &hours,&minutes,&seconds);
	while(1)
	{    system("cls");
	     printf("%02d : %02d : %02d",hours, minutes, seconds);
	   fflush(stdout);
	   	seconds++;
		if(seconds==60)
		{
			minutes+=1;
			seconds =0;
		}
			if(minutes==60)
		{   
		    hours+=1;
			minutes=0;
		}
			if(hours==24)
		{   hours=0;
			minutes=0;
			seconds =0;
		}
		sleep(1);
	}
}
