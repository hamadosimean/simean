from pytube import YouTube
from tkinter import *
from tkinter import messagebox
t=Tk()
t['bg']='darkblue'
t.title='Youtube'

def downloader():
    lien=str(link.get())
    url=YouTube(lien)
    if(lien=='' or lien==null):
        Label(t, text='Veuillez copiez le lien dans le champ',fg='red',bg='white',font='Georgia 10 bold').place(x=20,y=400)
    else:
       video=url.streams.first().download()
       Label(t, text='Telechargement terminé').place(x=20,y=400)
link=StringVar()
a="Fatiham Youtube video dowloader"
b=a.upper()
Label(t,text=b,fg='darkorange',bg='white',font='Georgia 10 bold').place(x=10,y=100)
c='Passer le lien du video ici'
c.upper()
Label(t,text=c,fg='darkorange',bg='white',font='Arial 9 bold').place(x=150,y=200)
Entry(t,textvariable=link,width=40).place(x=20,y=250)
Button(t,text='Télécharger',fg='darkorange',bg='white',font='Georgia 10 bold',command=downloader).place(x=200,y=300)
t.mainloop()