#include<iostream>
#include<iomanip>
#include<windows.h>
#include<cstdlib>
#include<ctime>
using namespace std;

class Vehicule {
	private:
		string nom;
		int id;
	// Private section
	public:
		// Public Declarations
		   Vehicule( );
		   ~Vehicule( );
           void setNom( string name );
           string getNom( );
           void setId( int ide);
           void traceLaLigne();
           int getId( );
           void exerciceUn();
};

class Voiture :public Vehicule {
	// Private section
	private:
		int nombrederoues;
	public:
		// Public Declarations
        void setNombrederoues( int number );
        int getNombrederoues( );
};

Vehicule::Vehicule( ){
}


Vehicule::~Vehicule( )
{
}
void Vehicule::setNom( string name ){
	nom=name;
}
string Vehicule::getNom(  ){
	return nom;
}

 void Vehicule::setId( int ide)
 {
 	id=ide;
 }
int Vehicule::getId( )
{
	return id;
}

void Voiture::setNombrederoues( int number )
{
	nombrederoues=number;
}
int Voiture::getNombrederoues()
{
	return nombrederoues;
}

void Vehicule::traceLaLigne()
{
	int i;
	for(i=0;i<40;i++)
	cout<<"\xdb";
}
COORD coord={0,0};
void gotoxy (int x, int y)
{
coord.X = x; coord.Y = y; // LES COORDONNE DE X ET Y
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void Vehicule::exerciceUn()
{
	char exerice[]={'E','X','E','R','C','I','C','E','1'};
	int n= sizeof(exerice);
	for(int i=0;i<n;i++){
	cout<<exerice[i];
	 Sleep(300);
    }
    cout<<endl;
}
void Remerciement()
{  	char thank[]=" MERCI BEAUCOUP AU Dr SERE";
	int l = strlen(thank);
	for (int i=0; i<l;i++)
	{
		cout<<thank[i];
		Sleep(300);
	}
}
void owner()
{ 
  for(int i=100; i>=60;i--)
  {  gotoxy(i,8);
  	cout<<" CE PROGRAMME A ETE PRESENTE PAR SIMEAN HAMADO ET BARRY ASSETOU ";
  	Sleep(300);
  }
}
int main( )
{   system("color 6");
	Voiture v,v1;
	gotoxy(62,2);v.exerciceUn();
	system("cls");
	gotoxy(60,2);v.traceLaLigne();
	cout<<endl;
	v.setNom("V8");
	v.setId(67);
	v.setNombrederoues(4);
	v1.setNom("RAV4");
	v1.setId(78);
	v1.setNombrederoues(6);
	gotoxy(62,3);cout<<"NOM"<<setw(11)<<"ID"<<setw(20)<<"Nombres de roues"<<endl;
	gotoxy(62,4);cout<<v.getNom();
	;cout<<setw(12)<<v.getId();
	;cout<<setw(12)<<v.getNombrederoues();
	gotoxy(62,5);cout<<v1.getNom();
	cout<<setw(10)<<v1.getId();
     cout<<setw(12)<<v1.getNombrederoues();
	cout<<endl;
	gotoxy(60,6);v.traceLaLigne( );
	owner( );
	gotoxy(65,10);
	Remerciement( );
}



