#include<iostream>
#ifndef INFORMATICIEN_H
#define INFORMATICIEN_H
using namespace std;
class Informaticien
{
	protected:
		Informaticien();
		void getIfosInformaticien( );
		void showIfosInformaticien( );
		~Informaticien();
	private:
		string nom;
		int id;
		string specialite;		
		
};

#endif
