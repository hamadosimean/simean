#include<iomanip>
#include "Statisticien.h"
using namespace std;

Statisticien::Statisticien( )
{
}

void Statisticien::getIfosStatisticien( )
{   
do{
	cout<<setw(98)<<"Entrer entrer le nom du statisticien:";
	cin.ignore( );
	getline(cin,nom);
	if(nom.empty( )){
	cout<<setw(98)<<"Ne laisser pas le champ vide"<<endl;
	getline(cin,nom);
     }
    }while( nom.empty( ) );
    do{
    cout<<setw(98)<<"Entrer votre l\'identifiant:";
    cin>>id;
   }while( id<0 );	
}

void Statisticien::showIfosStatisticien( )
{
	cout<<setw(28)<<nom<<setw(20)<<id<<endl;
}

Statisticien::~Statisticien()
{
}
