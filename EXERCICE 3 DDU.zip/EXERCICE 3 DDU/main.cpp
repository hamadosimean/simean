#include <iostream>
#include<iomanip>
#include<windows.h>
#include<ctime>
#include<cstdlib>
#include<unistd.h>
#include "Statisticien.h"
#include "Informaticien.h"

COORD coord={0,0};
void gotoxy (int x, int y)
{
coord.X = x; coord.Y = y; // LES COORDONNE DE X ET Y
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
class StatisticienInformaticien:public Statisticien,public Informaticien {
	// Private section
	private:
		int age;
		// Public Declarations
	public:
		void getDetails( );
		void showDetais( );
		// Protected Declarations
};

void StatisticienInformaticien:: getDetails( )
{    do{gotoxy(61,4);
	cout<<"Entrer l'age:";
	cin>>age;
    }while( age<0 );
    getIfosStatisticien( );
    getIfosInformaticien( );
    
}
void StatisticienInformaticien::showDetais( )
{    gotoxy(63,5);
	cout<<"Age"<<setw(23)<<"Nom"<<setw(20)<<"ID"<<setw(20)<<"SPECIALITE"<<endl;
	gotoxy(63,6);
	cout<<age;
	gotoxy(61,7);
	showIfosInformaticien( );
	gotoxy(61,8);
     showIfosStatisticien( );
}
void patientez()
{
	cout<<" VEUILLEZ PATIENTER ET AGGRANDISSEZ VOTRE ECRAN SVP";
	for(int i = 0; i<=100; i+=10)
	{
		cout<<".";
		Sleep(600);
	}
}

void Remerciement()
{     gotoxy(74,18);
	char thank[]=" MERCI BEAUCOUP AU Dr SERE";
	int l = strlen(thank);
	for (int i=0; i<l;i++)
	{
		cout<<thank[i];
		Sleep(300);
	}
}
void owner()
{ 
  for(int i=100; i>66;i--)
  {  gotoxy(i,16);
  	cout<<" CE PROGRAMME A ETE PRESENTE PAR SIMEAN HAMADO ET BARRY ASSETOU ";
  	Sleep(300);
  }
}
int main(int argc, char** argv) {
	StatisticienInformaticien s;
	system("color 0A");
	gotoxy(60,1);
	patientez();
	system("cls");
	gotoxy(60,3);
	for(int i =0; i<=80;i++)
	{
		cout<<"\xdb";
		Sleep(25);
	}
	for(int i=0;i<1;i++)
    {
    	int x = 60;
    	int y = 4;
    	for (y=4;y<13;y++)  
   		{
    	  gotoxy(x,y);
    	  cout << "\xdb";
    	  Sleep(100);
                                                 
  		}
  	}
	for(int i=0;i<1;i++)
    {
    	int x = 140;
    	int y = 4;
    	for (y=4;y<13;y++)  
   		{
    	  gotoxy(x,y);
    	  cout << "\xdb";
    	  Sleep(100);
  		}
  	}
  	gotoxy(60,13);
  		for(int i =0; i<=80;i++)
	{
		cout<<"\xdb";
		Sleep(25);
	}
	s.getDetails( );
	cout<<endl;
	system("cls");
	gotoxy(60,2);
	for(int i =0; i<=80;i++)
	{
		cout<<"\xdb";
		Sleep(25);
	}
	for(int i=0;i<1;i++)
    {
    	int x = 60;
    	int y =2;
    	for (y=2;y<13;y++)  
   		{
    	  gotoxy(x,y);
    	  cout << "\xdb";
    	  Sleep(100);
                                                 
  		}
  	}
	for(int i=0;i<1;i++)
    {
    	int x = 140;
    	int y = 2;
    	for (y=2;y<13;y++)  
   		{
    	  gotoxy(x,y);
    	  cout << "\xdb";
    	  Sleep(100);
  		}
  	}
  	gotoxy(60,13);
  		for(int i =0; i<=80;i++)
	{
		cout<<"\xdb";
		Sleep(25);
	}
	s.showDetais( );
	owner();
	Remerciement();
	return 0;
}
