#include "Informaticien.h"
#include<iomanip>
using namespace std;
Informaticien::Informaticien( )
{
}
void Informaticien::getIfosInformaticien( )
{   do{
	cout<<setw(100)<<"Entrer entrer le nom de l\'informaticien:";
	cin.ignore( );
	getline(cin,nom);
	if( nom.empty( )){
	cout<<setw(100)<<"Ne laisser pas le champ vide"<<endl;
	getline( cin,nom) ;
     }
    }while( nom.empty( ) );
    do{
	cout<<setw(110)<<"Entrer entrer le specialite de l\'informaticien:";
	cin.ignore( );
	getline(cin,specialite);
	if( nom.empty( )){
	cout<<setw(100)<<"Ne laisser pas le champ vide"<<endl;
	getline( cin,nom) ;
     }
    }while( nom.empty( ) );
    do{
    cout<<setw(98)<<"Entrer l\'identifiant:";
    cin>>id;
   }while( id<0 );	
}

void Informaticien:: showIfosInformaticien( )
{
	cout<<setw(28)<<nom<<setw(20)<<id<<setw(20)<<specialite<<endl;
}

Informaticien::~Informaticien( )
{
}
