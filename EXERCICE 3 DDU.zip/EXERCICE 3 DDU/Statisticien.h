#ifndef STATISTICIEN_H
#define STATISTICIEN_H
#include<iostream>
using namespace std;
class Statisticien
{
	protected:
		Statisticien( );
		void getIfosStatisticien( );
		void showIfosStatisticien( );
		~Statisticien( );
	private:
		string nom;
		int id;
		
};

#endif
