#include<iostream>//allows to input and ouput the results
#include<conio.h>
#include<stdlib.h>
#include<iomanip> //deals with space 
#include<string.h>// allows to handle string type

using namespace std; // allows to use the std

typedef struct{ char name[20];
        char surname[40];
        long int number;
        unsigned int age;// all the ages must be positive this is the reason of unsigned
        char sex;
        char fruit[30];
        char animal[40];
        char color[20];
} cards;  //creation d'un type cards

void creation_of_afile( char *carde)
{   char answ;
    cards fiche;
	FILE* card= fopen(carde,"wb");
	;
	cout<<"\nCREATION D'UNE FICHE"<<endl;

	do{
		cout<<">>Entrer votre nom:";cin>>fiche.name;
		cout<<">>Entrer votre prenom:";cin>>fiche.surname;
		cout<<">>Entrer votre age:"; cin>>fiche.age;
		cout<<">>Entrer votre sexe(M\\F):"; cin>>fiche.sex;
		cout<<">>Entrer votre numero de telephone:"; cin>>fiche.number;
		cout<<">>Entrer fruit favorie:"; cin>>fiche.fruit;
		cout<<">>Entrer animal favorie:"; cin>>fiche.animal;
		cout<<">>Entrer colour favorie:"; cin>>fiche.color;
		fwrite(&fiche,sizeof(cards),1,card);
		cout<<"\n>>AJOUTER UNE NOUVELLE FICHE?(O/N)\n"; answ=getch();
		cout<<"\n";
	}
	while(answ=='O'||answ=='o');
	fclose(card);
}




void add( char *carde)
{   char answ;
    cards fiche;
	FILE* card= fopen(carde,"ab");
	;
	cout<<"\n AJOUTER UNE FICHE"<<endl;

	do{
		cout<<">>Entrer votre nom:";cin>>fiche.name;
		cout<<">>Entrer votre prenom:";cin>>fiche.surname;
		cout<<">>Entrer votre age:"; cin>>fiche.age;
		cout<<">>Entrer votre sexe(M\\F):"; cin>>fiche.sex;
		cout<<">>Entrer votre numero de telephone:"; cin>>fiche.number;
		cout<<">>Entrer fruit favorie:"; cin>>fiche.fruit;
		cout<<">>Entrer animal favorie:"; cin>>fiche.animal;
		cout<<">>Entrer colour favorie:"; cin>>fiche.color;
		fwrite(&fiche,sizeof(cards),1,card);
		cout<<"\n>>AJOUTER UNE NOUVELLE FICHE?(O/N)\n"; answ=getch();
	    cout<<"\n";
	}
	while(answ=='O'||answ=='o');
	fclose(card);
}


void reading_the_card( char *carde)
{ FILE *card; int comp=1; cards fiche;
   card=fopen(carde,"rb");
   if(card==NULL){perror(">>>ERREUR D'OUVERTURE DU FICHIER");
   }
   else{ while(fread(&fiche,sizeof(cards),1,card)!=0)
   {cout<<"\n******************************************************************************************************";
    cout<<"\n>>>FICHIER NUMERO:\t"<<comp<<"\t";
    cout<<fiche.name<<"\t"<<fiche.surname<<"\t"<<fiche.age<<"\t"<<fiche.sex<<"\t"<<fiche.number<<"\t";
    cout<<"\t"<<fiche.fruit<<"\t"<<fiche.animal<<"\t"<<fiche.color<<endl;
    comp++;
   }
   }
   fclose(card);
}


void research( char *carde)
{ FILE* card; int comp=1; cards fiche; char found=0, nn[20], pp[40];
   card=fopen(carde,"rb");
   cout<<"\n>>>RECHERCHE DANS LE FICHIER"<<endl;
   cout<<">>Entrer le nom rechercher:"; cin>>nn;
   cout<<">>Entrer le prenom rechercher:"; cin>>pp;
   while((fread(&fiche,sizeof(cards),1,card))!=0&&found==0)
   {  
      if(strcmp(fiche.name,nn)==0&&strcmp(fiche.surname,pp)==0)
      { found=1;
	   cout<<"FICHIER TROUVEE, NUMERO:"<<comp<<"\t";
       cout<<fiche.name<<"\t"<<fiche.surname<<"\t"<<fiche.age<<"\t"<<fiche.sex<<"\t"<<fiche.number<<"\t";
       cout<<"\t"<<fiche.fruit <<"\t"<<fiche.animal<<"\t"<<fiche.color<<endl;
         comp++;
      }
      else {found==0;
      	 cout<<">>>CETTE FICHIER N'EXISTE PAS";
      }
      fclose(card);
   }

}


void quit()
{    char rep;
	cout<<"\n>>>VOULEZ VOUS QUITTER LE PROGRAMME(O\\N)";
	rep=getch();
	if(rep=='O'||rep=='o'){ cout<<"\nVOUS VENEZ DE QUITTER LE PROGRAMME";
	 exit(1);
	}
}



main()
{FILE* card; char my_lsie[50]="D:\\card.dat"; char answ;
   do{
      cout<<"\n        FICHE DE SOUVENIR"<<endl;
      cout<<"  *********************************\n";
      cout<<"  *    1 :CREATION DES FICHIER    *\n";
      cout<<"  *    2 :AFFICHER DES FICHIER    *\n";
      cout<<"  *    3 :AJOUTER DES FICHIER     *\n";
      cout<<"  *    4 :RECHERCHE D'UNE FICHIER *\n";
      cout<<"  *    Q :QUITTER                 *\n";
      cout<<"  *********************************\n";
      cout<<"            >>VOTRE CHOIX";
      answ=getch();
      switch(answ){ case '1':creation_of_afile( my_lsie); break;
                    case '2':reading_the_card( my_lsie); break;
                    case '3':add( my_lsie); break;
                    case '4':research( my_lsie); break;
                    case 'Q':quit();
      }
   } while(answ=='O'||answ!='o');
}
