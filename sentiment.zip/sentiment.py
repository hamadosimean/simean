from tkinter import *
from tkinter import messagebox
from textblob import TextBlob
t=Tk()
t.geometry('200x100')
t.title("FATIHAM")
t['bg']="blue"
def feeling():
    text=tex.get()
    if(text==' '):
        Label(t,text='Text vide',font='Arial 13 bold').place(x=200,y=350)
    else:
         obj=TextBlob(text)
         sentiment=obj.sentiment.polarity
         if(sentiment>0):
           Label(t,text='Sentiment positif',font='Arial 13 bold').place(x=200,y=350)
         if(sentiment<0):
           Label(t,text='Sentiment Negatif',font='Arial 13 bold').place(x=200,y=350)
         if(sentiment==0):
           Label(t,text='Sentiment Neutre',font='Arial 13 bold').place(x=200,y=350)
tex=StringVar()
Label(t,text="Ecrivez votre text ici. Je vous revele votre sentiment",width=45,bg='orange').place(x=5,y=150)
Entry(t,textvariable=tex,width=30).place(x=100,y=200)
Button(t,bg='orange',width=10,text="Sentiment",command=feeling).place(x=250,y=250)
t.mainloop()