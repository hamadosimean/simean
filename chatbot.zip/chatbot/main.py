from nltk.chat.util import Chat, reflections
pairs = [
    [
        r"(.*)my name is (.*)",
        ["Hello %2, How are you today ?", ]
    ],
    [
        r"(.*)(support|help)(.*) ",
        ["I can help you ", ]
    ],
    [
        r"(.*) (ai|artificial intelligence|deep learning|machine learning)",
        ["Artificial intellingence helps to perform task quickly and efficiently", "Machine learning is very good. It help to make prediction and classification !", ]
    ],
    [
        r"(.*)(reading|romance|novel|book|books|novels|read)(.*)",
        ["I a big fan of reading. I like novel CRAZY LOVE serie of SIMEAN HAMADO", "CRAZY LOVE serie is great for me. It is a romance and thriller serie !", "I like reading the best serie CRAZY LOVE", ]
    ],
    [
        r"(.*)(like ai|love tech|like tech|like machine learning|technology|love machine learning)(.*)",
        ["I love AI", "I love technology,  !", "I love machine learning",]
    ],
    [
        r"(.*) your name ?",
        ["My name is Fatiham, but you can just call me robot and I'm a chatbot .", ]
    ],
    [
        r"how (.*)(are you|feeling|up)(.*)",
        ["I'm doing very well", "i am great !"]
    ],
    [
        r"(.*)(french|hindi|language)(.*)",
        ["I only speak English", "I am not good at other language !"]
    ],
    [
        r"(.*)(study|studying|student|students|university)(.*)",
        ["Yes I study", "I am at university !"]
    ],
    [
        r"sorry (.*)",
        ["Its alright", "Its OK, never mind that", ]
    ],
[
        r"(.*)(AI)",
        ["AI stands for Artificial Intelligence", ]
    ],
    [
        r"(.*)(good|great|nice|well|okay|ok)(.*)",
        ["Nice to hear that", "Alright, great !", ]
    ],
    [
        r"(.*)(programming|computer program|Computer science|Computer)(.*)",
        ["I a big fan of computer science chiefly programming", "I like the field of computer science, chiefly the area of AI !", ]
    ],
    [
        r"(.*)(single|married|husband|grilfriend)(.*)",
        ["I am ashamed to tell you i am still a single girl", "I don't have husband 😒😒. I am ashamed to tell it to you !", ]
    ],
    [
        r"(.*) (Football burkina|Football Burkina faso)",
        ["Burkina Faso has a great football team Etalon", "Etalon is the name of the team of Burkina Faso football !", ]
    ],
    [
        r"(.*) (you from|live|living|country)",
        ["I am from Burkina Faso", "My country is Burkina Faso!", ]
    ],
    [
        r"(.*) (Burkina Faso|Faso|Burkina)",
        ["Burkina Faso is a country located in West Africa with over 20 millions people as population", "It is a country is west Africa !", ]
    ],
    [
        r"(.*)(flag)(.*)",
        ["The flag of burkina faso is consisted of red, yellow and green", "Red, yellow and green !", ]
    ],
    [
        r"(.*)(fatiham)(.*)",
        ["Thanks for still remembering my name kiss 😘😘", "You still remember my name. Thanks kiss 😘😘!", ]
    ],
    [
        r"(.*)(cupk|cup-k|cu-kaya|cuk)(.*)",
        ["Cup-kaya is a collegue which is located in Nord-center region", "Cup-k stands for Centre universitaire polytechnique de Kaya !", ]
    ],
    [
        r"(.*) (faculty|faculties|branches|subjects|branch) (.*)",
        ["There are six branches of study in CUP_kaya, viz LSIE, 2PIP, MPCI, CCA, GC, MQIA", "CUP-Kaya counts six branches of study !", ]
    ],
    [
        r"(hi|hey|hello|hola|holla)(.*)",
        ["Hello", "Hey there", ]
    ],
    [
        r"(.*) want ?",
        ["Make me an offer I can't refuse", ]

    ],
    [
        r"(.*)(unhappy|sorry|sad|glad)",
        ["I am sorry. I share the same sentiment !", ]

    ],
    [
        r"(.*) (sick|ill|sickness|illness)(.*)",
        ["I am sorry to here that. You have to go to hospital", "I don't feel happy to learn this.You have to go to hospital!","I am really sorry to hear this news.You have to go to hospital"]
    ],
    [
        r"(.*) (desease|death|dead)(.*)",
        ["I am very sorry to here that.", "I don't feel happy to learn this.!","I am really sorry to hear this news."]
    ],
    [
        r"(.*) (happy|happier|happiness|joy|joyfull|joyfulness|cheer|cheerful|cheerfulness|loved|thrilled)(.*)",
        ["Nice to hear that", "It is happy for me to hear this my lovely friend !", ]
    ],
    [
        r"(.*) (love|need|woo)you",
        ["I love you too. kiss!😘😘😘(●'◡'●)", "Alright, great !", ]
    ],
    [
        r"(.*) (friends|friend|parents|parent|family|child|children)(.*)",
        ["I don't have friends", "I don't have parents,  !", "My only one familly is SIMEAN HAMADO" ]
    ],
    [
        r"(.*) (programmed|created|author|master)(.*)",
        [" SIMEAN Hamado created me using Python's NLTK library ", "SIMEAN Hamado using NLTK librabry", ]
    ],
    [
        r"(.*) (location|city)(.*)",
        ['Kaya, BURKINA FASO', ]
    ],
    [
        r"(.*) (raining)(.*)",
        ["Almost every day it was rains.", "In %2 there is a 50% chance of rain", ]
    ],
    [
        r"(.*) (health)(.*)",
        ["Health is very important, but I am a computer, so I don't need to worry about my health ", ]
    ],
    [
        r"how (.*) (happy)(.*)",
        ["Everyone wants to be happy, even me. But i think to be happy you have to love yourself and to love what you. You need to laugh as well ", ]
    ],
    [
        r"(.*)(lie|liar|wrong)(.*)",
        ["Thanks for your feedback I am going to use it to improve myself ", ]
    ],
    [
        r"(.*) (sports|game|sport)(.*)",
        ["I'm a very big fan of football and basketball", ]
    ],
    [
        r"(.*) (CCA) (.*)?",
        ["CCA stands for Comptabilite Controle et Audit (Accounting)"]
    ],
    [
        r"(.*) (LSIE) (.*)?",
        ["LSIE stands for Statistics and Computer Science Related to economy "]
    ],
    [
        r"(.*) (MPCI) (.*)?",
        ["MPCI stands for Mathematique, Physique Chimie et Informatique"]
    ],
    [
        r"(.*) (2PIP) (.*)?",
        ["2PIP stands for psychologie "]
    ],
    [
        r"(.*) (MQIA) (.*)?",
        ["LSIE stands for Manangement en Qualite Industrielle AgroAlimentaire "]
    ],
    [
        r"quit",
        ["Bye for now. See you soon :) ", "It was nice talking to you. See you soon :)"]
    ],
    [
        r"(.*)",
        ['I am sorry I do not have this response for the moment!']
    ],
]
print("Hi, I'm Fatiham I am here assist you😘😘 ")
# Create Chat Bot
chat = Chat(pairs, reflections)
# Start conversation
chat.converse()