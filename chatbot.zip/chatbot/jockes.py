import pyjokes
import random
jock=random.choice(pyjokes.get_jokes())
print(jock)