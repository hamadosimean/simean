#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
 typedef struct Cupk {
     char nom[60];
	char prenom[60];
	int sexe;
	char filiere[30];
	int avis;
	int etat;
	int universite;
	int promotion;
	int religion;
	
} Cupk;


void saisiInfo()
{   Cupk c;
    char choix;
    FILE * fp;
    fp=fopen("cupk.txt","w");
    do{   
	   clrscr();
           printf("\nL\'etat de l\'etudiant (1 pour blanc et 2 pour autres):");
		   scanf("%d",&c.etat);
		   printf("\nNom de famille:");
		   scanf("%s",c.nom);
		   printf("\nPrenom:");
		   scanf("%s",c.prenom);
		   printf("\nSexe (1 si masculin et 2 si femminin):");
		   scanf("%d",&c.sexe);
		   printf("\nEtes vous du Cupk( 1 pour Cupk et 2 pour autres)?:");
		   scanf("%d",&c.universite);
		   printf("\nQuelle filiere faites-vous?:");
		   scanf("%s",c.filiere);
		   printf("\nVous faites la quelle ieme annee?:");
		   scanf("%d",&c.promotion);
		   printf("\nVotre religion svp (1 si musulman et 2 si chretiens et 3 pour autres):");
		   scanf("%d",&c.religion);
		   printf("\nEtes-vous pour ou contre cette activite? (1 pour et 2 contre):");
		   scanf("%d",&c.avis);
		   fwrite(&c,sizeof(Cupk),1,fp);
		   fclose(fp);
		   printf("\nVoulez vous ajouter une questionnaire(O ou N)");
		   choix=getch();
   }while(choix=='O' || choix=='o');
}

void display_items() //
{
    FILE*fp;
    Cupk c;
    int i = 1;
    fp=fopen("cupk.txt","r");
    printf(" \n\n\t===AFFICHAGE DE LA LISTE DES ETUDIANTS ENQUETER===");
    if(fp==NULL){
        fprintf(stderr, "\n\tImpossible d'ouvrir le fichier\n");
    }
    printf("\n\n\t======= ETUDIANTS ENREGISTRER ======\n\n");
    while (fread(&c,sizeof(Cupk),1,fp))
       { 
           printf("\t__________________________________\n"); 
		   printf("\tNumero de l\'etudiant    :: %d\n",i);
           printf("\tNom                     ::%s\n",c.nom);
           printf("\tPrenom                  ::%s\n",c.prenom);
           printf("\tSexe                    ::%d\n",c.sexe);
           printf("\tUniversite              ::%d\n",c.universite);
           printf("\tFiliere                 ::%s\n",c.filiere);
           printf("\tPromotion               ::%d\n",c.promotion);
           printf("\tReligion                ::%d\n",c.religion);
           printf("\tAvis   	                ::%d\n",c.avis);
           printf("\tEtat 	    	        ::%d\n",c.etat);
           i++;
       }       
	 fclose(fp);
 }
 
 
 
  void search()
{
    char nom[20];
    char prenom[30];
     FILE *fp;
     int i;
     i=1;
    Cupk c;
    fp=fopen("cupk.txt","r");
    printf("Entrer le nom a rechercher:");
    scanf("%s",nom);
    printf("Entrer le prenom a rechercher:");
    scanf("%s",prenom);
    while(fread(&c,sizeof(Cupk),1,fp))
    {
        if(strcmp(nom,c.nom)==0&&strcmp(prenom,c.prenom))
        {
            printf("\t__________________________________\n"); 
		   printf("\tNumero de l\'etudiant    :: %d\n",i);
           printf("\tNom                     ::%s\n",c.nom);
           printf("\tPrenom                  ::%s\n",c.prenom);
           printf("\tSexe                    ::%c\n",c.sexe);
           printf("\tUniversite              ::%d\n",c.universite);
           printf("\tFiliere                 ::%s\n",c.filiere);
           printf("\tPromotion               ::%d\n",c.promotion);
           printf("\tReligion                ::%d\n",c.religion);
           printf("\tAvis   	                ::%d\n",c.avis);
           printf("\tEtat 	    	        ::%d\n",c.etat);
           i++;
        }
        else{
            printf("Enregistrement non trouve...");
        }
    }
}
 
 
 
 
int nombre()
{   FILE*fp;
    Cupk c;
    int j = 0;
      fp=fopen("cupk.txt","r");
      while(fread(&c,sizeof(Cupk),1,fp))
	   fseek(fp,0,SEEK_END);
                j = ftell(fp)/sizeof(Cupk);
                printf("\n\t====informations detaillees====");
                printf("\n\tNombre d\'etudiants enqueter ::%d", j);
                printf("\n\t__________________________________\n"); 
    fclose(fp);
}


int Quit_programme()
{
	printf("\n\------------Vous venez de quitter le programme-----------");
	printf("\n\=======-COPYRIGHT SIMEAN HAMADO. All rights reserved-=======");
	}
	


int main(int argc, char *argv[])
{  char choix;
    clrscr();
	    while (choix!='0'){
	    printf("\n\t --------------------------------------------\n");
		printf("\t1.Enqueter un etudiant   \n");
		printf("\t2.Afficher                            \n");
		printf("\t3.Consulter le nombre de personnes enqueter\n");
		printf("\t4.Rechercher un etudiant   \n");
		printf("\t0.Quitter                                  \n");
		printf("\t--------------------------------------------\n"); 
		printf("\n");
		printf("\n\t\tFaite une option:");
		choix=getch();
	 switch(choix){
	     case '1': 
		 clrscr();
	     saisiInfo();
	      clrscr();
	      printf("\n\tAppuyez sur une touche pour continuer..");
	     getch();
	     clrscr();
	     break;
	     case '3':  
		 clrscr();
	     nombre();
	      printf("\n\tAppuyez sur une touche pour continuer..");
	     getch();
	     clrscr();
	     break;
	      case '4':  
		 clrscr();
	     search();
	      printf("\n\tAppuyez sur une touche pour continuer..");
	     getch();
	     clrscr();
	     break;
	     case '2':
	     	clrscr();
	     display_items();
	     printf("\n\tAppuyez sur une touche pour continuer..");
	     getch();
  	     clrscr();
	     break;
	     case '0':
	     	clrscr();
	     Quit_programme();
	     printf("\n\tAppuyez sur une touche pour continuer..");
	     getch();
  	     clrscr();
	     break;
	     default:
	      clrscr();
     	     printf("\n\tChoix non valide..Ressayer..\n");
     	     printf("\n\ttAppuyez sur une touche pour continuer..");
	     getch();
  	     clrscr();
	     	break;
}
}
}
